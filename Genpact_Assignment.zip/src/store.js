import { createStore, applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import AllReducers from './combineReducers';

export default function(initialstate) {
    const store = createStore(
      AllReducers,
      applyMiddleware(thunk)
    );

    return store; 
} 