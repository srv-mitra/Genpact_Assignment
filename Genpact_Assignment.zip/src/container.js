import { Provider } from 'react-redux';
import React from 'react';
import { Component } from 'react';
import configureStore from './store';
import App from './App';

const store = configureStore();

class Container extends Component{
    render(){
        return(
            <div>
                <Provider store={store}>
                    <App />
                </Provider>
            </div>
        );
    }
}

export default Container;