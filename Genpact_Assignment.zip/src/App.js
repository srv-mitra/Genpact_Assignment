import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getUserDetails } from './actions';

var empData = {"data":{"id":1,"first_name":"George","last_name":"Bluth","avatar":"https://s3.amazonaws.com/uifaces/faces/twitter/calebogden/128.jpg"}}
var deptData = {HR: [1,2,3,4,5], ENGINEERING: [6,7,8,9,10]};

class App extends Component {

  constructor(props){
    super(props);
    this.showDetails = this.showDetails.bind(this);
    this.clearData = this.clearData.bind(this);
  }


  getDepartMents(){
    var departments = [];

    for(var department in deptData){
      departments.push(
        <option>
          {department}
        </option>
      );
    }

    return departments;
  }

  changeDepartMent(e){
    for(var department in deptData){
      if(department == e.currentTarget.value){
        var ids = deptData[department];
        
        var selectElement = document.getElementById("select_employeeId");

        //removing previous options....
        while(selectElement.firstChild){
          selectElement.removeChild(selectElement.firstChild);
        }

        for(let i = 0; i < ids.length; i++){
          var option = document.createElement('option');
          option.innerText = ids[i];
          selectElement.appendChild(option);
        }

        selectElement.disabled = false;

        break;
      }
    }
  }

  getEmploees(){
    var options = [];
    var ids = deptData.HR;

    for(var i = 0; i < ids.length; i++){
      options.push(
        <option>{ids[i]}</option>
      );
    }

    return options;
  }

  showDetails(){
    var selectElement = document.getElementById("select_employeeId");

    if(selectElement != null){
      var empId = selectElement.value;

      this.props.getDetails(empId);
    }
    else{
      throw new Error("No select element found for Employee Id details....");
    }
  }

  clearData(){
    // var imgDiv = document.getElementById("imgDiv");
    // var detailsDiv = document.getElementById("detailsDiv");

    // if(imgDiv != null){
    //   imgDiv.style.display = "none";
    // }
    // else{
    //   throw new Error("image div was not found");
    // }

    // if(detailsDiv != null){
    //   detailsDiv.style.display = "none";
    // }
    // else{
    //   throw new Error("details div not found");
    // }

    this.props.getDetails(-1);
  }

  render() {

    var imagePath = "";
    var empId = "";
    var empName = "";

    if(this.props.UserDetails){
      imagePath = this.props.UserDetails.data.avatar;
      empId = this.props.UserDetails.data.id;
      empName = this.props.UserDetails.data.first_name + " " + this.props.UserDetails.data.last_name;
    }
    return (
      <div>
        <div className="container">
          <div className="first-DropDown">
            <label className="first-label">Departments:</label>
            <select className="department" onChange={this.changeDepartMent}>
              {this.getDepartMents()}
            </select>
          </div>

          <div className="second-dropDown">
            <label className="second-label">Employee ID:</label>
            <select className="employee" id="select_employeeId">
              {this.getEmploees()}
            </select>
          </div>
          <button onClick={this.showDetails} className="btnDetails">GetDetails</button>
          <button onClick={this.clearData} className="btnClear">Clear</button>
        </div>

        <div id="imgDiv" className="imageDiv" style={{display: this.props.UserDetails == null ? "none" : "block"}}>
          <img style={{marginLeft: "436px", width: "22%"}} id="user_image" src={imagePath} />
        </div>
        <div id="detailsDiv" style={{display: this.props.UserDetails == null ? "none" : "block"}}>
          <label style={{marginLeft: "436px", fontWeight: "bold"}}>ID: {empId}</label>
          <label style={{marginLeft: "110px", fontWeight: "bold"}}>Name: {empName}</label>
        </div>
        
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    UserDetails: state.UserDetails                                
  };
}

function mapDispatcherToProps(dispatch){
  return bindActionCreators({getDetails: getUserDetails}, dispatch);
}

export default connect(mapStateToProps, mapDispatcherToProps)(App);
