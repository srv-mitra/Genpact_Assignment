var $ = require('jquery');

export function getUserDetails(userId){
    var URL = "https://reqres.in/api/users/" + userId;

    return(dispatch, getState) => {
        if(userId != -1){
            $.ajax({
                url: URL,
                type: 'GET',
                dataType: '',
           
                success: function (data) {
                    dispatch(setUserDetails(data));
                },
                error: function (xhr) {
                    dispatch(setUserDetails(null));
                    throw new Error(xhr.statusText);
                }
            });
        }
        else{
            dispatch(setUserDetails(null));
        }
    }
}

function setUserDetails(data){
    return {data: data, type: "USERDETAILS"};
}