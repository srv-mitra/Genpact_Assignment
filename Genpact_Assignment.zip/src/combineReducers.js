import { combineReducers } from 'redux';
import UserDetails from './reducer';

var allReducer = combineReducers({
    UserDetails: UserDetails
});

export default allReducer;