export default function(state=null, action){
    switch(action.type){
        case "USERDETAILS" : return action.data
    }
    return state;
}